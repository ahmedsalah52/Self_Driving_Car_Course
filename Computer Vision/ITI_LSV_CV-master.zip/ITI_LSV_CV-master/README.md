# ITI Computer Vision for LSV Course

---

<p align="center">
  This course is provided to you by
</p>

---


<div align="center" width="100%">
    <img height="100" src="Files/iti.png"> 
</div>

<div align="center" width="100%" >
    <a href = "https://tekomoro.com/">
      <img width="250" src="Files/tekomoro.png"> 
    </a>
</div>

---

## Topics

---

## Basic Operations

- [Camera Terminology](01Basics/00_CameraTerminology.md)
- [Read Images, Videos, and CAM](01Basics/01_LoadandUnderstand.ipynb)
- [Pixel level operations](01Basics/02_Pixelwise.ipynb)
- [ROI 'Region of Interest' and Arethmatic operations](01Basics/03_ROI.ipynb)

## Image Processing

## Computer Vision

## Features (Extraction, and Matching)

## Machine Learning

---

## Projects

---

## Resources

### Books

- ROS:
  - ROS The Complete Reference
    - [Vol 1](https://link.springer.com/book/10.1007%2F978-3-319-26054-9)
    - [Vol 2](https://link.springer.com/book/10.1007/978-3-319-54927-9)
    - [Vol 3](https://link.springer.com/book/10.1007/978-3-319-91590-6)
    - [Vol 4](https://link.springer.com/book/10.1007/978-3-030-20190-6)
    - [Vol 5 _ Ros2](https://link.springer.com/book/10.1007/978-3-030-45956-7)

- OpenCV:
  - Practical Python and OpenCV
- Computer Vision:
  - [Computer Vision Algorithms and Applications](https://link.springer.com/book/10.1007/978-1-84882-935-0)
  - Computer vision A modern approach

### Websites

- [Papers With Code](https://paperswithcode.com/area/computer-vision)
- [Open CV](https://opencv.org)
- [Learn OpenCV](https://learnopencv.com)
- [PyImageSearch](https://www.pyimagesearch.com)
- [AI Shack](https://aishack.in)
